<!--<!DOCTYPE html>-->
<?php

$dbhandle = mysql_connect("localhost", "root", "") or die ("Unable to connect to MySQL");
$selected = mysql_select_db("test",$dbhandle) or die("Could not select examples");
echo "success";
?>

<?php

$firstname = $_POST['First_Name'];
$lastname = $_POST['Last_Name'];
$NIC = $_POST['NIC'];
$regno = $_POST['username'];
$address = $_POST['address'];
$email = $_POST['email'];
$faculty = $_POST['faculty'];
$password =md5($_POST['password']);
$contactno = $_POST['tel-number'];
$notification = $_POST['notification'];
mysql_query("insert into prospective_tenent(Reg_No,First_Name,Last_Name,Email,NIC,Faculty,Address,Contact_No,Password,Notification)VALUES('$regno','$firstname','$lastname','$email','$NIC','$faculty','$address','$contactno','$password','$notification')");

?>
<!--<!DOCTYPE html>-->
<html>
<head>
	<meta charset="UTF-8">
	<title>Blog - Student Accommodation Website</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" type="text/css" href="Template-IpadLoginJS/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="Template-IpadLoginJS/font-awesome/css/font-awesome.min.css" />

    <script type="text/javascript" src="Template-IpadLoginJS/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="Template-IpadLoginJS/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="header">
		<div>
			<a href="index.html" id="logo"><img src="images/logo.png" alt="logo"></a>
			<ul>
				<li>
					<a href="index.html"><span>H</span>ome</a>
				</li>
				<li>
					<a href="about.html"><span>A</span>bout</a>
				</li>
				<li>
					<a href="programs.html"><span>V</span>iew</a>
				</li>
				<li class="selected">
					<a href="blog.html"><span>L</span>ogin</a>
				</li>
				<li>
					<a href="staff.html"><span>S</span>taff</a>
				</li>
				<li>
					<a href="contact.html"><span>C</span>ontact</a>
				</li>
			</ul>
			<div>
				<p>
					<span>S</span>tudent <span>A</span>ccommodation <span>I</span>n: <span><span>Colombo</span></span>
				</p>
			</div>
		</div>
	</div>
	<!--<div class="body">
		<div>
			<div>
				<div>
					<div class="blog">
						<h2>Sign Up</h2>
						<div class="first">
						<!-- Interactive Login - START -->
						<div class="container">
							<!--<div class="row colored">-->
								<div id="contentdiv" class="contcustom">
									<span class="fa fa-spinner bigicon"></span>
									<h2>Login</h2>
									<div>
										<input id="username" type="text" placeholder="username" onkeypress="check_values();">
										<input id="password" type="password" placeholder="password" onkeypress="check_values();">
										<a href="student.html"><input type="submit" name="submit" value="Sign in" ></a>
										<div>
										<a href="application.html">Forgot your password?</a>
										</div>
										<!--<span id="lock1" class="fa fa-lock medhidden redborder"></span>-->
										
									   <!-- <button id="button1" class="btn btn-default wide hidden"> <span class="fa fa-check med"></span></button>
										<span id="lock1" class="fa fa-lock medhidden redborder"></span>-->
									</div>
								</div>
							</div>
						</div>

						<script type="text/javascript">


							function check_values() {
								if ($("#username").val().length != 0 && $("#password").val().length != 0) {
									$("#button1").removeClass("hidden").animate({ left: '250px' });;
									$("#lock1").addClass("hidden").animate({ left: '250px' });;
								}
							}


						</script>

						<style>
						.redborder {
							border:2px solid #f96145;
							border-radius:2px;
						}

						.hidden {
							display: none;
						}

						.visible {
							display: normal;
						}

						.colored {
							background-color: #F0EEEE;
						}

						.row {
							padding: 20px 0px;
						}

						.bigicon {
							font-size: 97px;
							color: #f96145;
						}

						.contcustom {
							text-align: center;
							width: 500px;
							border-radius: 0.5rem;
							top: 0;
							bottom: 0;
							left: 0;
							right: 0;
							margin: 10px auto;
							background : -moz-linear-gradient(#FF9900,#ffffcc,#ffffaa,#ffffbb,#FF9900,#ffffaa);
							padding: 20px;
						}

						input {
							width: 75%;
							margin-bottom: 17px;
							padding: 15px;
							background-color: #ECF4F4;
							border-radius: 2px;
							border: none;
						}

						h2 {
							margin-bottom: 20px;
							font-weight: bold;
							color: #ABABAB;
						}

						.btn {
							border-radius: 2px;
							padding: 10px;
						}

						.med {
							font-size: 27px;
							color: white;
						}

						.medhidden {
							font-size: 27px;
							color: #f96145;
							padding: 10px;
							width:100%;
						}

						.wide {
							background-color: #8EB7E4;
							width: 100%;
							-webkit-border-top-right-radius: 0;
							-webkit-border-bottom-right-radius: 0;
							-moz-border-radius-topright: 0;
							-moz-border-radius-bottomright: 0;
							border-top-right-radius: 0;
							border-bottom-right-radius: 0;
						}
						</style>

						
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer">
		<div>
			
			<div class="connect">
				<font size="3" color="gray"><b>FOLLOW US:</b></font>
				<a href="http://freewebsitetemplates.com/go/facebook/" class="facebook">Facebook</a> <a href="http://freewebsitetemplates.com/go/twitter/" class="twitter">Twitter</a> <a href="http://freewebsitetemplates.com/go/googleplus/" class="google">Google+</a>
			</div>
		</div>
		<div>
			<p>
				Student Accommodation &#169; 2014| All Rights Reserved
			</p>
		</div>
	</div>
</body>
</html>